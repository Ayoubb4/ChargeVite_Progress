<template>
  <div id="app">
    <HolaMundo />
    <ChangeMessage />
    <TaskList />
    <MyCounter />
    <RegisterForm />
  </div>
</template>

<script>
import HolaMundo from "@/components/HolaMundo.vue";
import ChangeMessage from "@/components/ChangeMessage.vue";
import TaskList from "@/components/TaskList.vue";
import MyCounter from "@/components/MyCounter.vue";
import RegisterForm from "@/components/RegisterForm.vue";



export default {
  name: 'App',
  components: {
    HolaMundo,
    ChangeMessage,
    TaskList,
    MyCounter,
    RegisterForm
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
