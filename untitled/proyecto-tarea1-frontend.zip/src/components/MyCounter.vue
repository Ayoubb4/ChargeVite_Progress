<script>
export default {
  data() {
    return {
      counter: 0
    };
  },

  methods: {
    increment() {
      this.counter++;
    },
    decrement() {
      this.counter--;
    }
  }
};
</script>

<template>
  <h1>Contador: {{ counter }}</h1>

  <button @click="increment">Suma</button>
  <button @click="decrement">Resta</button>
</template>

<style scoped>

</style>