<script>
export default {
  data() {
    return {
      message: 'Hola, presiona el botón para cambiar este mensaje.'
    };
  },
  methods: {
    changeMessage() {
      this.message = '¡Mensaje cambiado desde el componente!';
    }
  }
};
</script>

<template>

  <div>
    <h1>{{ message }}</h1>
    <button @click="changeMessage">Cambiar Mensaje</button>
  </div>

</template>

<style scoped>

</style>