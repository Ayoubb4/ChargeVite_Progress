<script>

  export default{
    data() {
      return{
        name: '',
        email: '',
        show: false
      };
    },

    methods: {
      showData() {
        this.show = true;
      }
    }
  };
</script>

<template>
<div>
  <h1> Formulario de Registro</h1>
  <input v-model="name" placeholder="Introduce tu nombre">
  <input v-model="email" placeholder="Introduce tu email">
  <button @click="showData">Mostrar Datos</button>

    <div v-if="show">
      <h2>Datos Ingresados:</h2>
      <p>Nombre {{ name}}</p>
      <p>Correo {{ email }}</p>
    </div>
</div>
</template>

<style scoped>

</style>