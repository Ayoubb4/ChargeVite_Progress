<script>
  export default {
    data(){
      return{
        mensaje: 'Hola mundo desde componente'
      };
    }
  };
</script>

<template>
  <div>
    <h1>{{ mensaje }}</h1>
  </div>
</template>

<style scoped>

</style>