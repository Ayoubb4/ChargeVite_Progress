<script>
  export default {
      data() {
        return {
          newTask: '',
          tasks: []
        };
      },
      methods: {
        addTask(){
          if(this.newTask !== ''){
            this.tasks.push(this.newTask);
            this.newTask = '';
          }
        },
        deleteTask(id){
          this.tasks.splice(id, 1);
        }
      }
  };
</script>

<template>
  <div>
    <h1> Mi Lista de Tareas</h1>
    <input v-model="newTask" type="text" placeholder="Añadir nueva Tarea" />
    <button @click="addTask">Añadir Tarea</button>

    <ul>
      <li v-for="(task ,id) in tasks" :key="id">
        {{ task }} <button @click="deleteTask(id)">Eliminar</button>
      </li>
    </ul>
  </div>
</template>

<style scoped>

</style>