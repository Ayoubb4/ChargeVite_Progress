import {
  GESTURE_CONTROLLER,
  createGesture
} from "./chunk-4AF7KAXZ.js";
import "./chunk-ZVATTXSA.js";
export {
  GESTURE_CONTROLLER,
  createGesture
};
